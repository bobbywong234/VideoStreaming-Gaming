'use strict';
var express = require('express');
var router = express.Router();


class external_websocket {
    constructor(blob_access_port) {
        const blob_websocket = new WebSocket('ws://localhost:${blob_access_port}')
        blob_websocket.onmessage = (msg) => {
            
        }
    }
}

/* GET users listing. */
router.get('/', function (req, res) {
    res.send('respond with a resource');
});

module.exports = router;
