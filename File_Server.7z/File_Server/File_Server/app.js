'use strict';
class HashMap {
    constructor(initialCapacity = 16, loadFactor = 0.9) {
        this.buckets = new Array(initialCapacity);
        this.loadFactor = loadFactor;
        this.size = 0; //number of itmes
        this.index = -1;
        this.collisions = 0;
        this.keys = []; // array length from 0-(n-1)
    }

    hash(key) {
        let hashValue = 0;
        const stringTypeKey = `${key}${typeof key}`;

        for (let index = 0; index < stringTypeKey.length; index++) {
            const charCode = stringTypeKey.charCodeAt(index);
            hashValue += charCode << (index * 8);
        }

        return hashValue;
    }


    _getBucketIndex(key) {
        const hashValue = this.hash(key);
        const bucketIndex = hashValue % this.buckets.length;
        return bucketIndex;
    }

    set(key, value) {
        const { bucketIndex, entryIndex } = this._getIndexes(key);

        if (entryIndex === undefined) {
            // initialize array and save key/value
            const keyIndex = this.keys.push({ content: key }) - 1; // keep track of the key index
            this.buckets[bucketIndex] = this.buckets[bucketIndex] || [];
            this.buckets[bucketIndex].push({ key, value, keyIndex });
            this.size++;
            this.index++;
            // Optional: keep count of collisions
            if (this.buckets[bucketIndex].length > 1) { this.collisions++; }
        } else {
            // override existing value
            this.buckets[bucketIndex][entryIndex].value = value;
        }

        // check if a rehash is due
        if (this.loadFactor > 0 && this.getLoadFactor() > this.loadFactor) {
            this.rehash(this.buckets.length * 2);
        }

        return this;
    }

    get(key) {
        const { bucketIndex, entryIndex } = this._getIndexes(key);

        if (entryIndex === undefined) {
            return;
        }

        return this.buckets[bucketIndex][entryIndex].value;
    }

    has(key) {
        return !!this.get(key);
    }

    _getIndexes(key) {
        const bucketIndex = this._getBucketIndex(key);
        const values = this.buckets[bucketIndex] || [];

        for (let entryIndex = 0; entryIndex < values.length; entryIndex++) {
            const entry = values[entryIndex];
            if (entry.key === key) {
                return { bucketIndex, entryIndex };
            }
        }

        return { bucketIndex };
    }

    delete(key) {
        const { bucketIndex, entryIndex, keyIndex } = this._getIndexes(key);

        if (entryIndex === undefined) {
            return false;
        }

        this.buckets[bucketIndex].splice(entryIndex, 1);
        delete this.keys[keyIndex];
        this.size--;

        return true;
    }

    rehash(newCapacity) {
        const newMap = new HashMap(newCapacity);

        this.keys.forEach(key => {
            if (key) {
                newMap.set(key.content, this.get(key.content));
            }
        });

        // update bucket
        this.buckets = newMap.buckets;
        this.collisions = newMap.collisions;
        // Optional: both `keys` has the same content except that the new one doesn't have empty spaces from deletions
        this.keys = newMap.keys;
    }

    getLoadFactor() {
        return this.size / this.buckets.length;
    }
}


var debug = require('debug');
var express = require('express');
var path = require('path');
//var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');


var routes = require('./routes/index');
var users = require('./routes/users');


var app = express();

//file streamming block
var web_socket_server = require('ws').Server;
var fs = require('fs');
var http = require('http');
var url = require('url');
var cluster = require('cluster');
var os = require('os');

/*
async function stream_video(response, start_bytes, end_bytes, duration, ran, path) {
    await new Promise(() => {
        response.writeHead(206,
        {
                'Access-Control-Expose-Headers': 'Content-Length, Content-Range',
                'Content-Range': 'bytes ' + start_bytes.toString() + '-' + end_bytes.toString() + '/' + duration.toString(),
                'Content-Length': ran.toString(),
                'Content-Type': "video/mp4",
                'Access-Control-Allow-Methods': 'GET,PUT',
                'Access-Control-Allow-Origin': "http://localhost:11876"
        });
        response.shouldKeepAlive = false;
        fs.createReadStream(path, { highWaterMark: ran, start: start_bytes, end: end_bytes }).pipe(response, { end: false });
    }).then(response.end());
}*/

if (cluster.isMaster) {
    console.log(`Master ${process.pid} is running and have ${os.cpus().length} cores`);
    var cores = os.cpus().length;
    var pid_collection = new HashMap();
    var path_record = "";
    var file_size_record = 0;

    function Master_manager(msg) {
        if (msg._end_proccess === true) {
            /*
            var delete_counting = -1;
            var cursor = 0;
            while (delete_counting < cores) {
                if (cluster.workers[cursor]) {
                    console.log(cursor);
                    cluster.workers[cursor].kill();
                    delete_counting++;
                }
                cursor++;
            }*/
            for (const id in cluster.workers) {
              cluster.workers[id].process.kill();
            }
        }
        if (msg._required_filesize_pid) {
            cluster.workers[parseInt(pid_collection.get(msg._required_filesize_pid), 10)].send({ _return_file_size: file_size_record });
        }
        if (msg._file_size) {
            file_size_record = msg._file_size;
        }
        if (msg._worker_number) {
            //key:pid,value:worker_index
            pid_collection.set(msg._worker_number.split(",")[1], msg._worker_number.split(",")[0]);
            console.log("key: " + msg._worker_number.split(",")[1] +" value: "+ pid_collection.get(msg._worker_number.split(",")[1]))
        }
        if (msg._file_path) {
            path_record = msg._file_path;
            console.log(`File Path has been Recorded; ${path_record}`);
        }
        
        if (msg._origin_pid) {
            pid_record = msg._origin_pid.toString();
            console.log(`First PID has been Recorded; ${pid_record}`);
        }
        if (msg._current_pid) {
            cluster.workers[parseInt(pid_collection.get(msg._current_pid),10)].send({ Renewed_path: path_record });
        }
    }

    for (let i = 0; i < cores; i++) {
        var worker = cluster.fork();
        worker.on('message', Master_manager);
        worker.send({ process_index: worker.id });
    }

    cluster.on('exit', (worker) => {
        console.log(`worker ${worker.process.pid} died`);
        pid_collection.delete(worker.process.pid);
        delete cluster.workers[worker.id];
        var new_worker = cluster.fork();
        new_worker.on('message', Master_manager);
        new_worker.send({ process_index: new_worker.id });
    });
}
else {
    //params
    var finised_handshake = "";
    //var file_path = "";
    //end
    process.setMaxListeners(0);
    process.on('message', function (msg) {
        if (msg.process_index) {
            console.log(msg.process_index + "/" + process.pid);
            process.send({ _worker_number: msg.process_index.toString() + "," + process.pid.toString() });
        }
    });

   var server = http.createServer(function (req, res) {
        req.on('data', msg => {
            finised_handshake = msg.toString();
        }).on('end', () => {
            if (finised_handshake === "true") {
                process.send({ _required_filesize_pid: process.pid.toString() });
                process.on('message', function (msg) {
                    if (msg._return_file_size) {
                        res.writeHead(200, {
                            'Access-Control-Allow-Methods': 'POST,PUT',
                            'Access-Control-Allow-Origin': 'http://localhost:11876',
                            'Access-Control-Allow-Credentials': 'true'
                        });
                        res.end(msg._return_file_size.toString());
                        finised_handshake = "false";
                    }
                });
            }
            /*
            if (url.parse(req.url, true).query["e"]) {
                process.send({ _end_proccess: true });
            }*/

            if (url.parse(req.url, true).query["NS"]) {
                console.log("Worker " + process.pid + " now sending whole video stream")
                res.setMaxListeners(0);
                res.writeHead(200,
                    {
                        'Content-Type': "video/mp4",
                        'Access-Control-Allow-Methods': 'GET,PUT',
                        'Access-Control-Allow-Origin': "http://localhost:11876",
                        'Access-Control-Allow-Credentials': 'true'
                    });
                process.send({ _current_pid: process.pid.toString() });
                process.on('message', function (msg) {
                    if (msg.Renewed_path) {
                        fs.createReadStream(
                            msg.Renewed_path,
                            { highWaterMark: 1024 * 64 }
                        ).pipe(res, { end: false });
                    }
                });
            }

            if (url.parse(req.url, true).query["id"] === "Stm") {
                var seg_start = parseInt(url.parse(req.url, true).query["SR"], 10);
                var seg_end = parseInt(url.parse(req.url, true).query["ER"], 10);
                var length = seg_end - seg_start+1;
                var buffering_length = parseInt(url.parse(req.url, true).query["BL"], 10);
                res.setMaxListeners(0);

                if (seg_start === 0) {
                    console.log("Worker " + process.pid + " Received first req, sending record...");
                }
                

                process.send({ _current_pid: process.pid.toString() });
                process.on('message', function (msg) {
                    if (msg.Renewed_path) {
                      
                       res.writeHead(206,
                       {
                       'Access-Control-Expose-Headers': 'Content-Length, Content-Range',
                       'Content-Range': 'bytes ' + seg_start.toString() + '-' + seg_end.toString() + '/' + buffering_length.toString(),
                       'Content-Length': length.toString(),
                       'Content-Type': "video/mp4",
                       'Access-Control-Allow-Methods': 'GET,PUT',
                       'Access-Control-Allow-Origin': "http://localhost:11876"
                       });

                        res.shouldKeepAlive = false;
                        fs.createReadStream(msg.Renewed_path, { highWaterMark: length, start: seg_start, end: seg_end })
                            .pipe(res, { end: false });
                        //  stream_video(res, seg_start, seg_end, buffering_length, length, msg.Renewed_path);
                    }
                });
            }
        }).connection.setKeepAlive(false).setTimeout(20000);

    }).listen(8080);
    // end
    /*
    // Maintain a hash of all connected sockets
    var sockets = {}, nextSocketId = 0;
    server.on('connection', function (socket) {
        // Add a newly connected socket
        var socketId = nextSocketId++;
        sockets[socketId] = socket;
        console.log('socket', socketId, 'opened');

        // Remove the socket when it closes
        socket.on('close', function () {
            console.log('socket', socketId, 'closed');
            delete sockets[socketId];
            nextSocketId--;
        });

        // Extend socket lifetime for demo purposes
        socket.setTimeout(4000);
    });
    /*
    // Count down from 10 seconds
    (function countDown(counter) {
        console.log(counter);
        if (counter > 0)
            return setTimeout(countDown, 1000, counter - 1);

        // Close the server
        server.close(function () { console.log('Server closed!'); });
        // Destroy all open sockets
        for (var socketId in sockets) {
            console.log('socket', socketId, 'destroyed');
            sockets[socketId].destroy();
        }
    })(10);
    */
    //websokcet
    var wss = new web_socket_server({ port: 7000 });
    wss.on('connection', function (ws) {
        ws.onmessage = function (msg) {
            if (msg.data != null && msg.data != 'end') {
                var file_size = fs.statSync(msg.data).size;
                var fixed_range = 1024*1024;
                process.send({ _file_size: file_size });
                var cores = os.cpus().length;
                var buffering_length = 0;
                var Whether_segmenting = "";
                if (file_size / fixed_range < cores)
                {
                    buffering_length = file_size;
                    Whether_segmenting = "n";
                }
                else
                {
                    buffering_length = (Math.floor(file_size / 2)).toString();
                    Whether_segmenting = cores;
                }
                console.log(buffering_length);
                ws.send(fixed_range.toString() + "," + buffering_length + "," + Whether_segmenting);
                process.send({_file_path: msg.data.toString() });
            }

            console.log(msg.data);
            if (msg.data === "end") {
                console.log('yes');
                process.send({ _end_proccess: true });
            }
        };
    });
//end
    console.log(`Worker ${process.pid} started`);
}

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);
app.use('/users', users);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(function (err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            error: err
        });
    });
}


// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        error: {}
    });
});

//app.set('port', process.env.PORT || 3000);

var server = app.listen(app.get('port'), function () {
    debug('Express server listening on port ' + server.address().port);
});